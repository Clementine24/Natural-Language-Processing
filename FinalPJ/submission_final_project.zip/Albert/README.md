# ALBert

该部分主要实现了该问题下的ALBert模型，分为sequence classification和multiple choice两个子任务。

该目录下的Albert.ipynb和AlbertMC.ipynb均为源代码文件。

运行需要在该目录下导入以下数据文件（可以在: https://github.com/wangcunxiang/SemEval2020-Task4-Commonsense-Validation-and-Explanation 下载获得）：

+ subtaskA_answers_all.csv
+ subtaskA_data_all.csv
+ subtaskA_dev_data.csv
+ subtaskA_dev_gold_answers.csv
+ subtaskA_test_data.csv
+ subtaskA_test_gold_answers.csv
+ taskA_trial_data.csv
+ taskA_trial_gold_answers.csv

如果想要运行训练好的模型，需要在百度网盘（https://pan.baidu.com/s/1QUDJrmBArujjzYC0ql3FAg?pwd=ecya）的ALBERT文件夹中下载model_save和model_save_69两个压缩文件，并解压缩文件夹，并将其放在该目录下。