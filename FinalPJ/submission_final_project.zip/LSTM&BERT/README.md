# LSTM and BERT family

该目录包含LSTM、`BertForMaskLM`、`BertForSequenceClassification`、`BertForMultipleChoice`四个不同模型的实现，分别位于各ipynb文件中。run_mlm_no_trainer.py是用于训练MLM模型的代码。

由于只包含代码，不包含数据及预训练模型，代码不能直接运行。

若要直接运行各ipynb文件，请下载百度网盘链接：
https://pan.baidu.com/s/1QUDJrmBArujjzYC0ql3FAg?pwd=ecya
中的BERT文件夹，在/BERT/code目录下即可直接运行。